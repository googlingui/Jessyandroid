# Jessy — app Android (MVP)

Jessy é um protótipo Android nativo em Kotlin + Jetpack Compose, com interface delicada em roxo e uma conversa demonstrativa.

## Importante sobre a versão atual
- Este MVP usa respostas locais de demonstração; **ainda não está conectado a um modelo de IA real**.
- Nenhuma mensagem é enviada pela internet nesta versão.
- O histórico da conversa fica apenas na memória enquanto o app está aberto; ainda não há armazenamento permanente.
- Não inclua uma chave secreta de API dentro do aplicativo. Para usar IA real, conecte o app a um backend seguro que guarde a chave no servidor.

## Gerar APK com Android Studio
1. Instale o Android Studio e o Android SDK (API 35 ou mais recente).
2. Extraia o ZIP e abra a pasta `JessyAndroid` no Android Studio.
3. Aguarde o Gradle Sync. Se solicitado, instale o Android Gradle Plugin/SDK indicado pelo Android Studio.
4. Para testar: **Run > Run 'app'** com um dispositivo Android conectado ou emulador.
5. Para criar um APK de teste: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira o APK para seu celular e autorize a instalação desta fonte, se o Android solicitar.

## Gerar pelo terminal
Com JDK 17 e Android SDK configurados, dentro da pasta do projeto:
- Windows: `gradlew.bat assembleDebug`
- macOS/Linux: `./gradlew assembleDebug`

O arquivo de saída fica em `app/build/outputs/apk/debug/app-debug.apk`.

## APK de lançamento
Para distribuir fora do Android Studio, crie uma chave de assinatura em **Build > Generate Signed Bundle / APK** e guarde a chave e as senhas em local seguro. Não compartilhe sua chave privada.

## Próximos passos para uma IA real
1. Criar um backend HTTPS (por exemplo, em um servidor próprio).
2. Guardar a chave do provedor de IA apenas no backend.
3. O app envia o texto para o backend e exibe a resposta.
4. Definir política de privacidade, retenção de dados e opção para apagar conversas.
5. Adicionar tratamento cuidadoso para situações de crise emocional e deixar claro que o app não é um serviço de emergência nem substitui apoio profissional.

## Build in the cloud (without installing Android Studio)
The project includes `.github/workflows/build-apk.yml` for a GitHub Actions cloud build. Upload the project files to a GitHub repository, open the repository's **Actions** tab, choose **Build Jessy APK**, tap **Run workflow**, and wait for the run to finish. Open the successful run and download the `Jessy-debug-APK` artifact. GitHub may require account sign-in and repository setup. This creates a debug APK for testing, not a store-ready signed release.

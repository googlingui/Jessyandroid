package com.jessy.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Lavender = Color(0xFF8B5CF6)
private val Pale = Color(0xFFF7F0FF)
private val Ink = Color(0xFF35264A)
private val SoftPurple = Color(0xFFE9DDFB)

data class ChatMessage(val text: String, val fromJessy: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JessyApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JessyApp() {
    var draft by remember { mutableStateOf("") }
    var demoMode by remember { mutableStateOf(true) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Oi, meu bem 💜 Eu sou a Jessy. Este é um cantinho para conversar sem julgamentos. Como você está se sentindo hoje?", true)
        )
    }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Lavender,
            onPrimary = Color.White,
            background = Pale,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier.size(42.dp).background(SoftPurple, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Favorite, contentDescription = null, tint = Lavender)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Jessy", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink)
                                Text("seu cantinho de conversa", fontSize = 12.sp, color = Lavender)
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            messages.clear()
                            messages.add(ChatMessage("Oi, meu bem 💜 Podemos recomeçar. O que está passando pela sua cabeça?", true))
                        }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Nova conversa", tint = Lavender)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            },
            bottomBar = {
                Surface(color = Color.White, shadowElevation = 8.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth().imePadding().padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Box(
                            modifier = Modifier.weight(1f).background(Pale, RoundedCornerShape(22.dp)).padding(horizontal = 16.dp, vertical = 13.dp)
                        ) {
                            if (draft.isBlank()) Text("Pode me contar...", color = Color(0xFF9C8EAA))
                            BasicTextField(
                                value = draft,
                                onValueChange = { draft = it },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 16.sp),
                                maxLines = 5
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                val text = draft.trim()
                                if (text.isNotEmpty()) {
                                    messages.add(ChatMessage(text, false))
                                    draft = ""
                                    messages.add(ChatMessage(demoReply(text), true))
                                    scope.launch { listState.animateScrollToItem(messages.lastIndex) }
                                }
                            },
                            modifier = Modifier.size(48.dp).background(Lavender, CircleShape)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar", tint = Color.White)
                        }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Surface(
                    color = Color.White.copy(alpha = 0.78f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        "Você merece ser ouvida com carinho. 🌷",
                        modifier = Modifier.padding(14.dp),
                        color = Ink,
                        fontSize = 14.sp
                    )
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.fromJessy) Arrangement.Start else Arrangement.End
                        ) {
                            Surface(
                                color = if (msg.fromJessy) Color.White else SoftPurple,
                                shape = RoundedCornerShape(
                                    topStart = 20.dp, topEnd = 20.dp,
                                    bottomStart = if (msg.fromJessy) 5.dp else 20.dp,
                                    bottomEnd = if (msg.fromJessy) 20.dp else 5.dp
                                ),
                                shadowElevation = 1.dp,
                                modifier = Modifier.widthIn(max = 310.dp)
                            ) {
                                Text(msg.text, modifier = Modifier.padding(15.dp), color = Ink, fontSize = 15.sp, lineHeight = 22.sp)
                            }
                        }
                    }
                }
                Text(
                    "Jessy é um apoio para conversar, não substitui ajuda profissional.",
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp),
                    color = Color(0xFF8D7C9D),
                    fontSize = 11.sp
                )
            }
        }
    }
}

private fun demoReply(text: String): String {
    val t = text.lowercase()
    return when {
        listOf("triste", "sozinha", "sozinho", "chor", "dor", "cansada", "cansado").any { it in t } ->
            "Sinto muito que esteja doendo assim. 💜 Você não precisa organizar tudo perfeitamente para me contar. Vamos com calma, um pedacinho de cada vez. O que está mais difícil neste momento?"
        listOf("ansiedade", "medo", "nervosa", "nervoso", "pânico").any { it in t } ->
            "Vamos desacelerar um pouquinho juntas? 🌷 Se for confortável, apoie os pés no chão e solte o ar devagar. Você não precisa resolver tudo agora. O que ajudaria você a se sentir um pouco mais segura neste instante?"
        listOf("feliz", "alegre", "consegui", "conquista").any { it in t } ->
            "Que bom que você dividiu isso comigo! 💜 Quer me contar mais sobre o que aconteceu? Vale a pena dar espaço também às coisas boas."
        else ->
            "Obrigada por confiar em mim para contar isso. 💜 Quero entender melhor, sem te julgar. Você pode me falar um pouco mais sobre o que isso significa para você?"
    }
}
